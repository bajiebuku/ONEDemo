//
//  AppDelegate.h
//  ONEDemo
//
//  Created by 韩东 on 17/7/4.
//  Copyright © 2017年 HD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

